package com.example.course_app.data.api

object ApiConstants {

    const val BASE_URL = "https://native-team-code-test-api.herokuapp.com/"

    /*Course*/
    const val API_COURSE = "api/courses"



    }