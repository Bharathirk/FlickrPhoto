package com.example.course_app.data.di.modules


import dagger.Module


@Module
interface FragmentBuildersModule {


}