package com.example.course_app.data.response.common

object ResponseStatus {
    val ERROR = 0
    val SUCCESS = 1
}