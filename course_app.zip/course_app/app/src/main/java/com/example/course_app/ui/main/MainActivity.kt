package com.example.course_app.ui.main

import android.os.Bundle
import androidx.lifecycle.ViewModelProvider
import com.example.course_app.R
import com.example.course_app.BR
import com.example.course_app.base.BaseActivity
import com.example.course_app.data.viewmodels.base.BaseViewModel
import com.example.course_app.data.viewmodels.main.MainViewModel
import com.example.course_app.databinding.ActivityMainBinding
import com.example.course_app.helper.tab.TabsModel
import com.example.course_app.ui.course.CourseFragment

class MainActivity : BaseActivity<ActivityMainBinding, MainNavigator>(){
    private var activityChatBinding: ActivityMainBinding? = null
    private var mainViewModel: MainViewModel? = null
    private var mAdapter: TabAdapter? = null

    override fun getLayoutId(): Int {
        return R.layout.activity_main
    }

    override fun getViewBindingVarible(): Int {
        return BR.mainViewModel
    }

    override fun getViewModel(): BaseViewModel<MainNavigator> {
        mainViewModel =
            ViewModelProvider(this, viewModelFactory).get(MainViewModel::class.java)
        return mainViewModel!!
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        activityChatBinding = getViewDataBinding()

        getTabView()
        activityChatBinding!!.viewPager.setOffscreenPageLimit(mAdapter!!.getCount())
        activityChatBinding!!.viewPager.setAdapter(mAdapter)
        activityChatBinding!!.tabs.setupWithViewPager(activityChatBinding!!.viewPager)
    }
    private fun getTabView() {
        val tabsList = ArrayList<TabsModel>()
        tabsList.add(TabsModel(CourseFragment.getInstance(), "Course", ""))
        tabsList.add(TabsModel(CourseFragment.getInstance(), "Skipped", ""))
        mAdapter = TabAdapter(supportFragmentManager, tabsList, this)

    }


}
