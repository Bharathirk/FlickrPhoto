package com.example.course_app.data.viewmodels.main

import com.example.course_app.data.viewmodels.base.BaseViewModel
import com.example.course_app.ui.course.CourseNavigator
import com.example.course_app.ui.main.MainNavigator
import javax.inject.Inject

class MainViewModel  @Inject constructor() : BaseViewModel<MainNavigator>(){
}