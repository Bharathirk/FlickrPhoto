package com.example.course_app.ui.course

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.course_app.R
import com.example.course_app.BR
import com.example.course_app.base.BaseFragment
import com.example.course_app.data.response.course.CourseResponse
import com.example.course_app.data.response.course.CourseResponseItem
import com.example.course_app.data.viewmodels.base.BaseViewModel
import com.example.course_app.data.viewmodels.course.CourseViewModel
import com.example.course_app.databinding.FragmentCourseBinding

class CourseFragment:BaseFragment<FragmentCourseBinding, CourseNavigator>() {
    companion object {
        fun getInstance():Fragment {
            return CourseFragment().apply {
            }
        }
    }
    private var fragmentCourseBinding: FragmentCourseBinding? = null
    private var courseViewModel: CourseViewModel? = null
    private var courseAdapter: CourseAdapter? = null

    override fun getLayoutId(): Int {
        return R.layout.fragment_course
    }

    override fun getViewModel(): BaseViewModel<CourseNavigator> {
        courseViewModel =
            ViewModelProvider(this, viewModelFactory).get(CourseViewModel::class.java)
        return courseViewModel!!
    }

    override fun getViewBindingVarible(): Int {
        return BR.courseViewModel
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        fragmentCourseBinding = getViewDataBinding()

        courseAdapter = CourseAdapter()
        fragmentCourseBinding?.courseAdapter = courseAdapter

        getCourse()
    }

    private fun getCourse() {
        courseViewModel!!.getCourse().observe(viewLifecycleOwner, { response ->
            if (response?.data != null) {
                val chatResponse = response.data as CourseResponse
                setView(chatResponse.courseResponse as List<CourseResponseItem>?)
            } else {
                showToast(response.throwable?.message!!)
            }
        })
    }

    private fun setView(breakss: List<CourseResponseItem>?) {
        courseAdapter!!.setCourseAdapter(breakss )
    }
}