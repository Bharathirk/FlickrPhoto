package com.example.course_app.base

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.annotation.LayoutRes
import androidx.appcompat.app.AlertDialog
import androidx.databinding.DataBindingUtil
import androidx.databinding.ViewDataBinding
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.course_app.R
import com.example.course_app.app.AppController
import com.example.course_app.data.bus.MainThreadBus
import com.example.course_app.data.preferences.AppPreference
import com.example.course_app.data.viewmodels.base.BaseViewModel
import com.example.course_app.databinding.ActivityBaseBinding
import dagger.android.support.DaggerFragment
import io.realm.Realm
import kotlinx.android.synthetic.main.progress_bar.view.*
import javax.inject.Inject

abstract class BaseFragment<VB : ViewDataBinding, V : Any> : DaggerFragment() {

    @Inject
    lateinit var viewModelFactory: ViewModelProvider.Factory
    @Inject
    lateinit var appPreference: AppPreference
    @Inject
    lateinit var bus: MainThreadBus


    private var dialog: AlertDialog? = null
    private var viewBinding: VB? = null
    private var viewModel: BaseViewModel<V>? = null
    private var baseBinding: ActivityBaseBinding?=null
    var realm: Realm?=null

    @LayoutRes
    abstract fun getLayoutId(): Int

    abstract fun getViewModel(): BaseViewModel<V>

    abstract fun getViewBindingVarible(): Int

    fun getViewDataBinding(): VB {
        return viewBinding!!
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        baseBinding = DataBindingUtil.inflate(inflater, R.layout.activity_base, container, false)
        return baseBinding!!.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setDataBinding()
        observeLoadingStatus()
    }

    private fun setDataBinding() {
        viewBinding = DataBindingUtil.inflate(layoutInflater, getLayoutId(), baseBinding!!.frameContent, true)
        this.viewModel = getViewModel()
        viewBinding!!.setVariable(getViewBindingVarible(), viewModel)
        viewBinding!!.executePendingBindings()
        realm= AppController.getInstance()?.getRealm()!!
    }

    protected fun showToast( input: String?) {
        Toast.makeText(context, input, Toast.LENGTH_SHORT).show()
    }


    protected fun showLoading() {
        baseBinding!!.includProgress.progress_bar.visibility = View.VISIBLE
    }

    protected fun hideLoading() {

        baseBinding!!.includProgress.progress_bar.visibility = View.INVISIBLE
    }

    protected fun observeLoadingStatus() {
        viewModel!!.loadingStatus.observe(viewLifecycleOwner, Observer { isLoading ->
            if (!isLoading!!) {
                hideLoading()
            } else {
                showLoading()
            }
        })
    }

}