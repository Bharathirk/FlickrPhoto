package com.example.course_app.app

object AppConstants {
//    const val APP_DATABASE_NAME: String = "Chat"

}

