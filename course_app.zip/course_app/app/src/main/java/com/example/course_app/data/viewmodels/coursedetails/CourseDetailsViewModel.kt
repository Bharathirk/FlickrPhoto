package com.example.course_app.data.viewmodels.coursedetails

class CourseDetailsViewModel {
}