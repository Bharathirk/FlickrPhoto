package com.example.course_app.data.viewmodels.course

import androidx.lifecycle.MutableLiveData
import com.example.course_app.data.response.common.AppResponse
import com.example.course_app.data.viewmodels.base.BaseViewModel
import com.example.course_app.ui.course.CourseNavigator
import javax.inject.Inject

class CourseViewModel @Inject constructor() : BaseViewModel<CourseNavigator>() {

    fun getCourse(): MutableLiveData<AppResponse<Any>> {
        val responseBody = MutableLiveData<AppResponse<Any>>()
        api.getCourse()
            .compose(RxJavaUtils.applyObserverSchedulers())
            .compose(RxJavaUtils.applyErrorTransformer())
            .doOnSubscribe { loadingStatus.value = true }
            .doOnTerminate { loadingStatus.value = false }
            .subscribe({ response ->
                if (response != null) {
                    responseBody.value = AppResponse.success(response)
                }
            }, { throwable ->
                responseBody.value = AppResponse.error(throwable)
            })

        return responseBody
    }


}