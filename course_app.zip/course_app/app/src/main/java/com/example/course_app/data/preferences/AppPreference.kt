package com.example.course_app.data.preferences

import android.content.Context
import android.content.SharedPreferences
import javax.inject.Inject

class AppPreference @Inject constructor(context: Context) {

    companion object {
        private val PREFERENCE_NAME = "DATABINDING_PREF"

    }

    private val preferences: SharedPreferences

    init {
        preferences = context.getSharedPreferences(PREFERENCE_NAME, Context.MODE_PRIVATE)
    }

    /*---------------------------------------------------------Clear Preference -----------------------------------------------------------*/
    fun clearAppPreference() {
        preferences.edit().clear().apply()
    }

}
