package com.example.course_app.ui.course

interface CourseNavigator {
}