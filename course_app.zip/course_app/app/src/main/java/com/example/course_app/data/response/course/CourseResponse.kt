package com.example.course_app.data.response.course

import com.google.gson.annotations.SerializedName

data class CourseResponse(

	@field:SerializedName("CourseResponse")
	val courseResponse: List<CourseResponseItem?>? = null
)

data class CourseResponseItem(

	@field:SerializedName("icon_url")
	val iconUrl: String? = null,

	@field:SerializedName("teacher_name")
	val teacherName: String? = null,

	@field:SerializedName("number_of_topics")
	val numberOfTopics: Int? = null,

	@field:SerializedName("name")
	val name: String? = null,

	@field:SerializedName("id")
	val id: String? = null,

	@field:SerializedName("last_attempted_ts")
	val lastAttemptedTs: Int? = null
)
