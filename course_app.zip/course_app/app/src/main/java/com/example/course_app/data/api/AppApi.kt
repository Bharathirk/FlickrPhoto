package com.example.course_app.data.api

import com.example.course_app.data.response.course.CourseResponse
import retrofit2.http.*
import rx.Observable

interface AppApi {
    @GET(ApiConstants.API_COURSE)
    fun getCourse(): Observable<CourseResponse>
}