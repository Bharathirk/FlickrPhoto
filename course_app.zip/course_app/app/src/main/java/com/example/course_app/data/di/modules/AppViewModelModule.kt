package com.example.course_app.data.di.modules

import androidx.lifecycle.ViewModel
import com.example.course_app.data.di.keys.ViewModelKey
import com.example.course_app.data.viewmodels.course.CourseViewModel
import com.example.course_app.data.viewmodels.history.HistoryViewModel
import dagger.Binds
import dagger.Module
import dagger.multibindings.IntoMap

@Module
abstract class AppViewModelModule {

    @Binds
    @IntoMap
    @ViewModelKey(CourseViewModel::class)
    internal abstract fun bindChatViewModel(chatViewModel: CourseViewModel): ViewModel

    @Binds
    @IntoMap
    @ViewModelKey(HistoryViewModel::class)
    internal abstract fun bindHistoryViewModel(historyViewModel: HistoryViewModel): ViewModel

}