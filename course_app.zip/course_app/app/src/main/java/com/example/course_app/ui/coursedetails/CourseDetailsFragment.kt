package com.example.course_app.ui.coursedetails

class CourseDetailsFragment {
}