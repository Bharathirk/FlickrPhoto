package com.example.course_app.data.di.modules

import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
interface ActivityBuildersModule {

    @ContributesAndroidInjector
    fun contributeSplashActivity(): MainActivity

}