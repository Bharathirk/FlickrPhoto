package com.example.course_app.ui.main

interface MainNavigator {
}