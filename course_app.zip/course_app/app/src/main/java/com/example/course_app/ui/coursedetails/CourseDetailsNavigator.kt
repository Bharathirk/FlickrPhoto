package com.example.course_app.ui.coursedetails

interface CourseDetailsNavigator {
}