package com.example.course_app.data.di.modules

import androidx.lifecycle.ViewModelProvider
import com.example.course_app.data.factory.DaggerViewModelFactory
import dagger.Binds
import dagger.Module

@Module
abstract class ViewModelFactoryModule {

    @Binds
    internal abstract fun bindViewModelFactory(factoryApp: DaggerViewModelFactory): ViewModelProvider.Factory

}