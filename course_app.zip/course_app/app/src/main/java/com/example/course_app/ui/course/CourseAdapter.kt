package com.example.course_app.ui.course

import android.databinding.DataBindingUtil
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.course_app.R
import com.example.course_app.data.response.course.CourseResponseItem
import com.example.course_app.databinding.ItemCourseBinding

class CourseAdapter:RecyclerView.Adapter<CourseAdapter.ChatHolder>() {
    private var courseResponseItem: List<CourseResponseItem>? = null

    init {
        courseResponseItem = ArrayList()
    }

    fun setCourseAdapter(item: List<CourseResponseItem>?) {
        if (item == null) {
            return
        }
        courseResponseItem = item
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChatHolder {
        return ChatHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_course, parent, false))
    }

    override fun onBindViewHolder(holder: ChatHolder, position: Int) {
        val item: CourseResponseItem = courseResponseItem?.get(position)!!
        val binding: ItemCourseBinding = holder.getBinding()
        binding.courseResponseItem = item
    }

    override fun getItemCount(): Int {
        return courseResponseItem!!.size
    }

    inner class ChatHolder(itemView:View):RecyclerView.ViewHolder(itemView) {
        private var binding: ItemCourseBinding? = null
        init {
            binding = DataBindingUtil.bind(itemView)
        }

        fun getBinding(): ItemCourseBinding {
            return binding!!
        }
    }
}